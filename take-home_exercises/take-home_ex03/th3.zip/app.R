pacman::p_load(shiny, sf, tmap, bslib, tidyverse,
               sfdep, shinydashboard, shinythemes, lubridate)

msia <- read_rds("data/rds/msia.rds")
msia_left_join <- read_rds("data/rds/msia_left_join.rds")
msia_total_crimes <- read_rds("data/rds/msia_total_crimes.rds")
east_msia <- read_rds("data/rds/EAST_MSIA.rds")

#========================#
###### Shiny UI ######
#========================#  

#|fig-width: 12
#|fig-height: 10
#|
basemap <- tm_shape(msia_total_crimes) +
  tm_borders(alpha = 0.5) +
  tm_text("ADM2_EN", size=0.4) + 
  tm_layout(
    main.title = "Basemap with districts",
    main.title.size = 1,
    main.title.position = "center",
    legend.show = FALSE,
    frame = FALSE)


ui <- navbarPage(
  title = "Malaysia",
  fluid = TRUE,
  theme=shinytheme("cosmo"),
  id = "navbarID",
  tabPanel("Home"),
  navbarMenu("EDA",
             tabPanel("Basemap",
                      fluidPage(
                        fluidRow(
                          column(12, 
                                 sliderInput(inputId = "basemap_opacity",
                                             label = "Basemap Transparency",
                                             min = 0,
                                             max = 1,
                                             value = 0.5)
                          )
                        ),
                        fluidRow(
                          column(12,
                                 tmapOutput("basemapOutput", width = "100%", height = 580)
                          )
                        )
                      )
             ),
             tabPanel("Visualisation",
                      sidebarLayout(
                        sidebarPanel(
                          selectInput(inputId = "variable",
                                      label = "Types of Crimes",
                                      choices = list("total crimes" = "total_crimes", 
                                                     "causing injury" = "total_crimes_causing_injury",
                                                     "murder" = "total_crimes_murder",
                                                     "rape" = "total_crimes_rape",
                                                     "robbery gang armed" = "total_crimes_robbery_gang_armed",
                                                     "robbery gang unarmed" = "total_crimes_robbery_gang_unarmed",
                                                     "robbery gang solo armed" = "total_crimes_robbery_solo_armed",
                                                     "robbery gang solo unarmed" = "total_crimes_robbery_solo_unarmed"
                                      ),
                                      selected = "total_crimes"),
                          selectInput(inputId = "classification",
                                      label = "Classification method:",
                                      choices = list("sd" = "sd", 
                                                     "equal" = "equal", 
                                                     "pretty" = "pretty", 
                                                     "quantile" = "quantile", 
                                                     "kmeans" = "kmeans", 
                                                     "hclust" = "hclust", 
                                                     "bclust" = "bclust", 
                                                     "fisher" = "fisher", 
                                                     "jenks" = "jenks"),
                                      selected = "equal"),
                          sliderInput(inputId = "classes",
                                      label = "Number of classes",
                                      min = 5,
                                      max = 10,
                                      value = c(6)),
                          selectInput(inputId = "colour",
                                      label = "Colour scheme:",
                                      choices = list("blues" = "Blues", 
                                                     "reds" = "Reds", 
                                                     "greens" = "Greens",
                                                     "Yellow-Orange-Red" = "YlOrRd",
                                                     "Yellow-Orange-Brown" = "YlOrBr",
                                                     "Yellow-Green" = "YlGn",
                                                     "Orange-Red" = "OrRd"),
                                      selected = "YlOrRd"),
                          sliderInput(inputId = "opacity",
                                      label = "Level of transparency",
                                      min = 0,
                                      max = 1,
                                      value = c(0.5))
                        ),
                        mainPanel(
                          tmapOutput("mapPlot",
                                     width = "100%", 
                                     height = 580)
                        )
                      )
             ),
  ),
  navbarMenu("Spatial Weights and Application",
             tabPanel("Global Measures"),
             tabPanel("Local Measures"),
             tabPanel("EHSA")
             ),
  navbarMenu("Spatial Model"),
)

#========================#
###### Shiny Server ######
#========================# 

server <- function(input, output){
  output$basemapOutput <- renderTmap({
    tm_shape(msia_total_crimes) +
      tm_fill(col = "lightblue", alpha = input$basemap_opacity) +  # Add color and transparency
      tm_borders(alpha = 0.5) +
      tm_text("ADM2_EN", size = 0.7) + 
      tm_layout(
        main.title = "Basemap with districts",
        main.title.size = 1,
        main.title.position = "center",
        legend.show = FALSE,
        frame = FALSE
      ) +
      tm_view(set.view = c(lon = 112.796783, lat = 3.420404, zoom = 7))  # More zoomed-in view
  })
  
  output$mapPlot <- renderTmap({
    tmap_options(check.and.fix = TRUE) +
      tm_shape(msia_total_crimes) +  # Show ADM2_EN on hover
      tm_fill(
        input$variable,
        n = input$classes,
        style = input$classification,
        palette = input$colour,
        alpha = input$opacity,
        popup.vars = c("Total Crimes" = "total_crimes", "District" = "ADM2_EN", "State" = "ADM1_EN")
      ) +
      tm_borders(lwd = 0.1, alpha = 1) +
      tm_view(set.zoom.limits = c(6.5, 8))
  })
    
    #==========================================================
    # Local Measures of Spatial AutoCorrelation
    #==========================================================   
    
    localMIResults <- eventReactive(input$MoranUpdate,{

      if(nrow(msia) == 0) return(NULL)  # Exit if no data

      # Computing Contiguity Spatial Weights
      wm_q <- msia %>%
        mutate(nb = st_contiguity(geometry,
                                  queen = !!input$Contiguity1),
               wt = st_weights(nb,
                               style = input$MoranWeights))

      # Computing Local Moran's I

      lisa <- wm_q %>%
        mutate(local_moran = local_moran(
          msia$GDPPC, nb, wt,
          nsim = as.numeric(input$MoranSims)),
          .before = 5) %>%
        unnest(local_moran)

      lisa <- lisa %>%
        rename("local moran(ii)" = "ii", "expectation(eii)" = "eii",
               "variance(var_ii)" = "var_ii", "std deviation(z_ii)" = "z_ii",
               "p_value" = "p_ii")

      return(lisa)
    })
    
    #==========================================================
    # Render output maps
    #==========================================================
    
    #Render local Moran I statistics
    # output$LocalMoranMap <- renderTmap({
    #   df <- localMIResults()
    #   
    #   if(is.null(df) || nrow(df) == 0) return()  # Exit if no data
    #   
    #   # Map creation using tmap
    #   localMI_map <- tm_shape(df) +
    #     tm_fill(col = input$localmoranstats, 
    #             style = "pretty", 
    #             palette = "RdBu", 
    #             title = input$localmoranstats) +
    #     tm_borders() +
    #     tm_view(set.zoom.limits = c(6, 7))
    #   
    #   localMI_map 
    # })

    #Render LISA map 
    # output$LISA <- renderTmap({
    #   df <- localMIResults()
    #   if(is.null(df)) return()
    #   
    #   
    #   lisa_sig <- df  %>%
    #     filter(p_value < as.numeric(input$MoranConf))  
    #   
    #   lisamap <- tm_shape(df) +
    #     tm_polygons() +
    #     tm_borders() +
    #     
    #     tm_shape(lisa_sig) +
    #     tm_fill(col = input$LisaClass,  
    #             palette = "-RdBu",  
    #             title = (paste("Significance:", input$LisaClass))) +
    #     tm_borders(alpha = 0.4) +
    #     tm_view(set.zoom.limits = c(6, 7))
    # 
    #   lisamap 
    # })
}

shinyApp (ui=ui, server=server)

